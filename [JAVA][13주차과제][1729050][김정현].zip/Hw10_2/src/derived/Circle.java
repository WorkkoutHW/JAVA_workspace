package derived;
import base.Shape;

public class Circle extends Shape{
	public void draw() { System.out.println("Circle"); }
}
